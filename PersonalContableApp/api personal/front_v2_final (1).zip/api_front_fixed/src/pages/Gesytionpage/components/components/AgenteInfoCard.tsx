// components/AgenteInfoCard.tsx
// Muestra el perfil completo del agente tal como lo devuelve GET /personal/:dni
// (personal + agentes + catálogos + servicios + foto path)
import React from 'react';

interface Props { row: any; }

function Campo({ label, value }: { label: string; value?: string | number | null }) {
  if (!value && value !== 0) return null;
  return (
    <div style={{ marginBottom: 4 }}>
      <span style={{ fontSize: '0.68rem', color: '#94a3b8', textTransform: 'uppercase',
        letterSpacing: '0.05em', marginRight: 6 }}>{label}</span>
      <span style={{ fontSize: '0.87rem' }}>{String(value)}</span>
    </div>
  );
}

function Badge({ text, color = '#1e40af' }: { text: string; color?: string }) {
  return (
    <span style={{ background: color + '33', color, border: `1px solid ${color}55`,
      borderRadius: 5, padding: '1px 8px', fontSize: '0.74rem', marginRight: 4 }}>
      {text}
    </span>
  );
}

export function AgenteInfoCard({ row }: Props) {
  if (!row) return null;

  const nombre = `${row.apellido || ''}${row.nombre ? `, ${row.nombre}` : ''}`;
  const estadoColor = row.estado_laboral === 'ACTIVO' || row.estado_empleo === 'ACTIVO'
    ? '#16a34a' : '#dc2626';

  // Servicio principal (primer elemento de servicios[])
  const servicioPpal = row.servicios?.[0];

  return (
    <div className="card gp-card-14">
      {/* Encabezado */}
      <div style={{ marginBottom: 10 }}>
        <h3 className="gp-h3-top0" style={{ marginBottom: 4, fontSize: '1rem' }}>
          {nombre || '(sin nombre)'}
        </h3>
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 4 }}>
          {(row.estado_empleo || row.estado_laboral) && (
            <Badge text={row.estado_empleo || row.estado_laboral} color={estadoColor} />
          )}
          {row.ley_nombre && <Badge text={row.ley_nombre} color="#7c3aed" />}
          {row.planta_nombre && <Badge text={row.planta_nombre} color="#0369a1" />}
        </div>
      </div>

      {/* Datos personales */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '2px 12px' }}>
        <Campo label="DNI"      value={row.dni} />
        <Campo label="CUIL"     value={row.cuil} />
        <Campo label="Legajo"   value={row.legajo} />
        <Campo label="Email"    value={row.email} />
        <Campo label="Teléfono" value={row.telefono} />
        <Campo label="Domicilio" value={row.domicilio} />
        <Campo label="Nacimiento"
          value={row.fecha_nacimiento
            ? new Date(row.fecha_nacimiento).toLocaleDateString('es-AR')
            : undefined} />
      </div>

      {/* Separador datos laborales */}
      <div style={{ borderTop: '1px solid rgba(255,255,255,0.08)', margin: '8px 0' }} />

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '2px 12px' }}>
        <Campo label="Categoría"       value={row.categoria_nombre} />
        <Campo label="Función"         value={row.funcion_nombre} />
        <Campo label="Ocupación"       value={row.ocupacion_nombre} />
        <Campo label="Régimen"         value={row.regimen_horario_nombre} />
        <Campo label="Dependencia"     value={row.dependencia_nombre} />
        <Campo label="Ingreso"
          value={row.fecha_ingreso_laboral || row.fecha_ingreso
            ? new Date(row.fecha_ingreso_laboral || row.fecha_ingreso).toLocaleDateString('es-AR')
            : undefined} />
        {row.fecha_egreso && (
          <Campo label="Egreso"
            value={new Date(row.fecha_egreso).toLocaleDateString('es-AR')} />
        )}
      </div>

      {/* Primer servicio vigente */}
      {servicioPpal && (
        <>
          <div style={{ borderTop: '1px solid rgba(255,255,255,0.08)', margin: '8px 0' }} />
          <div style={{ fontSize: '0.75rem', color: '#94a3b8', marginBottom: 2 }}>SERVICIO PRINCIPAL</div>
          <div style={{ fontSize: '0.87rem' }}>{servicioPpal.servicio_nombre}</div>
          {servicioPpal.fecha_desde && (
            <div style={{ fontSize: '0.72rem', color: '#64748b' }}>
              Desde {new Date(servicioPpal.fecha_desde).toLocaleDateString('es-AR')}
              {servicioPpal.fecha_hasta
                ? ` → ${new Date(servicioPpal.fecha_hasta).toLocaleDateString('es-AR')}`
                : ' (vigente)'}
            </div>
          )}
        </>
      )}

      {/* Total documentos */}
      {row.totalDocumentos !== undefined && (
        <div style={{ marginTop: 8, fontSize: '0.75rem', color: '#64748b' }}>
          📄 {row.totalDocumentos} documento(s) en archivo
        </div>
      )}
    </div>
  );
}
