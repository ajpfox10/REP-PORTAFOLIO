// components/AgenteSearchForm.tsx
// FIX: Agrega botón "Buscar nombre" visible (antes solo Enter).
// El botón es importante en touch/mobile y hace la función obvia.
import React from 'react';

interface Props {
  dni: string;
  fullName: string;
  loading?: boolean;
  onDniChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
  onFullNameChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
  onSearch: () => void;
  onSearchByName: () => void;
}

export function AgenteSearchForm({
  dni, fullName, loading,
  onDniChange, onFullNameChange,
  onSearch, onSearchByName
}: Props) {
  return (
    <div className="card gp-card-14">
      {/* Row 1: DNI */}
      <div className="search-row" style={{ marginBottom: 8 }}>
        <div className="search-field" style={{ flex: 2 }}>
          <label className="label">DNI</label>
          <input
            className="input"
            value={dni}
            onChange={onDniChange}
            onKeyDown={e => e.key === 'Enter' && onSearch()}
            placeholder="Ej: 30123456"
            disabled={loading}
            inputMode="numeric"
          />
        </div>
        <div style={{ display: 'flex', alignItems: 'flex-end' }}>
          <button
            className="btn"
            type="button"
            onClick={onSearch}
            disabled={loading || !dni.replace(/\D/g, '')}
            style={{ background: '#2563eb', color: '#fff', borderColor: '#1d4ed8',
              minWidth: 80, height: 36 }}
          >
            {loading ? '⏳' : '🔍 DNI'}
          </button>
        </div>
      </div>

      {/* Separador visual */}
      <div style={{ fontSize: '0.7rem', color: '#64748b', marginBottom: 6, textAlign: 'center' }}>
        — o buscar por nombre —
      </div>

      {/* Row 2: Nombre */}
      <div className="search-row">
        <div className="search-field" style={{ flex: 2 }}>
          <label className="label">Apellido / Nombre</label>
          <input
            className="input"
            value={fullName}
            onChange={onFullNameChange}
            onKeyDown={e => e.key === 'Enter' && onSearchByName()}
            placeholder="Ej: GARCIA JUAN"
            disabled={loading}
          />
        </div>
        <div style={{ display: 'flex', alignItems: 'flex-end' }}>
          <button
            className="btn"
            type="button"
            onClick={onSearchByName}
            disabled={loading || !fullName.trim()}
            style={{ minWidth: 80, height: 36 }}
          >
            {loading ? '⏳' : '🔍 Nombre'}
          </button>
        </div>
      </div>
    </div>
  );
}
