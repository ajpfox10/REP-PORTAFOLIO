// hooks/useAgenteSearch.ts
// ─────────────────────────────────────────────────────────────────────────────
// FIXES:
//   1. Búsqueda por DNI → usa GET /personal/:dni (perfil completo, un solo call)
//   2. Búsqueda por nombre → usa GET /personal/search?q= (endpoint dedicado)
//   3. Se eliminó el flujo multi-step (agentexdni1 → agentes/:id) que fallaba
//      cuando la tabla no tenía agente_id o el endpoint /agentes/:id no existía
// ─────────────────────────────────────────────────────────────────────────────
import { useState, useCallback } from 'react';
import { useToast } from '../../../ui/toast';
import { apiFetch } from '../../../api/http';
import { trackAction } from '../../../logging/track';

export function useAgenteSearch() {
  const toast = useToast();
  const [state, setState] = useState({
    dni: '',
    fullName: '',
    matches: [] as any[],
    loading: false,
    row: null as any,
  });

  // ── Buscar por DNI (usa GET /personal/:dni — perfil completo) ──────────────
  const onSearch = useCallback(async () => {
    const clean = state.dni.replace(/\D/g, '');
    if (!clean || clean.length < 6) {
      toast.error('DNI inválido', 'Ingresá al menos 6 dígitos');
      return;
    }

    try {
      setState(s => ({ ...s, loading: true, row: null, matches: [] }));

      // GET /personal/:dni devuelve perfil completo:
      // personal + agentes + catálogos (ley_nombre, planta_nombre, etc.) + servicios
      const res = await apiFetch<any>(`/personal/${clean}`);

      if (!res?.ok || !res?.data) {
        toast.error('No encontrado', `No hay agente con DNI ${clean}`);
        setState(s => ({ ...s, loading: false }));
        return;
      }

      setState(s => ({ ...s, loading: false, row: res.data }));
      toast.ok('Agente cargado', `${res.data.apellido}, ${res.data.nombre}`);
      trackAction('gestion_load_agente_by_dni', { dni: clean });
    } catch (e: any) {
      setState(s => ({ ...s, loading: false }));
      const msg = e?.message || 'Error';
      toast.error('No se pudo cargar el agente', msg);
      trackAction('gestion_load_agente_by_dni_error', { dni: clean, message: msg });
    }
  }, [state.dni, toast]);

  // ── Buscar por apellido/nombre (usa GET /personal/search?q=) ──────────────
  const onSearchByName = useCallback(async () => {
    const q = state.fullName.trim();
    if (!q) {
      toast.error('Búsqueda inválida', 'Ingresá apellido y/o nombre');
      return;
    }

    try {
      setState(s => ({ ...s, loading: true, matches: [], row: null }));

      // /personal/search?q= hace búsqueda en apellido Y nombre simultáneamente
      // y devuelve ley_nombre, planta_nombre, etc. de una vez
      const res = await apiFetch<any>(
        `/personal/search?q=${encodeURIComponent(q)}&limit=30&page=1`
      );

      const lista: any[] = res?.data || [];
      setState(s => ({ ...s, loading: false, matches: lista }));

      if (!lista.length) {
        toast.error('Sin resultados', `No hay agentes que coincidan con "${q}"`);
      } else {
        toast.ok(`${lista.length} resultado(s)`, 'Clic para cargar agente');
      }

      trackAction('gestion_search_by_name', { q, results: lista.length });
    } catch (e: any) {
      setState(s => ({ ...s, loading: false }));
      toast.error('Error al buscar', e?.message || 'Error');
    }
  }, [state.fullName, toast]);

  // ── Cargar agente directamente por DNI (desde MatchesList) ────────────────
  const loadByDni = useCallback(async (dniValue: string) => {
    const clean = String(dniValue).replace(/\D/g, '');
    setState(s => ({ ...s, dni: clean, matches: [], loading: true, row: null }));

    try {
      const res = await apiFetch<any>(`/personal/${clean}`);
      if (!res?.ok || !res?.data) throw new Error('No encontrado');
      setState(s => ({ ...s, loading: false, row: res.data }));
      toast.ok('Agente cargado', `${res.data.apellido}, ${res.data.nombre}`);
    } catch (e: any) {
      setState(s => ({ ...s, loading: false }));
      toast.error('Error al cargar agente', e?.message || 'Error');
    }
  }, [toast]);

  return {
    dni:      state.dni,
    fullName: state.fullName,
    matches:  state.matches,
    loading:  state.loading,
    row:      state.row,
    // cleanDni siempre string limpio — usado por useModules, useDocumentos, etc.
    cleanDni: state.row?.dni ? String(state.row.dni).replace(/\D/g, '') : '',

    setDni:      (dni: string) => setState(s => ({ ...s, dni })),
    setFullName: (fullName: string) => setState(s => ({ ...s, fullName })),
    clearMatches: () => setState(s => ({ ...s, matches: [] })),

    onSearch,
    onSearchByName,
    loadByDni,
  };
}
