// hooks/useModules.ts
// ─────────────────────────────────────────────────────────────────────────────
// FIXES:
//   1. Al cambiar cleanDni → resetear TODOS los módulos (rows + open + state)
//      BUG ANTERIOR: closeModule solo ponía open=false pero rows quedaban
//      del agente anterior → al abrir el módulo para el nuevo agente,
//      current.rows.length > 0 impedía el refetch → datos viejos
//   2. El endpoint de documentos ahora usa /personal/:dni/documentos
//      en lugar del CRUD genérico /tblarchivos?dni= (más semántico y rápido)
//   3. Consultas y pedidos siguen usando CRUD genérico con filtro ?dni=
// ─────────────────────────────────────────────────────────────────────────────
import { useState, useCallback, useEffect, useRef } from 'react';
import { useToast } from '../../../ui/toast';
import { apiFetch } from '../../../api/http';
import { trackAction } from '../../../logging/track';

export type ModuleKey = 'consultas' | 'pedidos' | 'documentos';

export type ModuleState = {
  open: boolean;
  rows: any[];
  selectedIndex: number;
  loading: boolean;
  scanned: { pages: number; totalPages: number; total: number } | null;
  tablePage: number;
  tablePageSize: number;
};

const EMPTY_MODULE = (): ModuleState => ({
  open: false, rows: [], selectedIndex: 0,
  loading: false, scanned: null, tablePage: 1, tablePageSize: 50,
});

const INITIAL_STATE = (): Record<ModuleKey, ModuleState> => ({
  consultas:  EMPTY_MODULE(),
  pedidos:    EMPTY_MODULE(),
  documentos: EMPTY_MODULE(),
});

export function useModules(cleanDni: string) {
  const toast = useToast();
  const prevDniRef = useRef<string>('');

  const [modules, setModules] = useState<Record<ModuleKey, ModuleState>>(INITIAL_STATE());

  // ── CRÍTICO: resetear todos los módulos cuando cambia el agente ────────────
  // Antes: closeModule solo ponía open=false. Al reabrir el módulo para el
  // nuevo DNI, current.rows.length > 0 evitaba el fetch → datos del agente anterior.
  useEffect(() => {
    if (!cleanDni) return;
    if (cleanDni === prevDniRef.current) return;  // mismo agente, no resetear
    prevDniRef.current = cleanDni;

    // Reset completo: borrar rows, cerrar módulos, limpiar estado
    setModules(INITIAL_STATE());
  }, [cleanDni]);

  // ── Cargar módulo ──────────────────────────────────────────────────────────
  const loadModule = useCallback(async (
    table: ModuleKey,
    opts?: { forceReload?: boolean }
  ) => {
    if (!cleanDni) {
      toast.error('Primero buscá un agente', 'Ingresá un DNI válido');
      return;
    }

    const current = modules[table];
    if (current.loading) return;

    // Abrir panel aunque ya tenga datos
    setModules(prev => ({ ...prev, [table]: { ...prev[table], open: true } }));
    trackAction('gestion_module_open', { module: table, dni: Number(cleanDni), forceReload: !!opts?.forceReload });

    // Si ya tiene datos y no se fuerza recarga → no volver a buscar
    if (current.rows.length && !opts?.forceReload) return;

    try {
      setModules(prev => ({
        ...prev,
        [table]: { ...prev[table], loading: true, rows: [], selectedIndex: 0, scanned: null, tablePage: 1 }
      }));

      let allRows: any[] = [];
      let scanned = { pages: 1, totalPages: 1, total: 0 };

      if (table === 'documentos') {
        // ── Endpoint dedicado: /personal/:dni/documentos ─────────────────────
        // Más rápido y semántico que el CRUD genérico. Soporta ?tipo= y ?q=
        const limit = 100;
        let page = 1;
        while (true) {
          const res = await apiFetch<any>(`/personal/${cleanDni}/documentos?limit=${limit}&page=${page}`);
          const rows: any[] = res?.data || [];
          const meta = res?.meta;
          if (page === 1) {
            scanned.total = meta?.total ?? rows.length;
            scanned.totalPages = meta?.totalPages ?? 1;
          }
          allRows = [...allRows, ...rows];
          if (!rows.length || rows.length < limit || page >= scanned.totalPages) break;
          page++;
          if (allRows.length >= 2000) break;
        }
        scanned.pages = page;

      } else {
        // ── CRUD genérico para consultas y pedidos ──────────────────────────
        const limit = 200;
        let page = 1;
        while (true) {
          const res = await apiFetch<any>(`/${table}?dni=${cleanDni}&limit=${limit}&page=${page}`);
          const rows: any[] = res?.data || [];
          const meta = res?.meta;
          if (page === 1) {
            scanned.total = meta?.total ?? rows.length;
            scanned.totalPages = Math.max(1, Math.ceil(scanned.total / limit));
          }
          allRows = [...allRows, ...rows];
          if (!rows.length || rows.length < limit || page >= scanned.totalPages) break;
          page++;
          if (allRows.length >= 2000) break;
        }
        scanned.pages = page;
      }

      setModules(prev => ({
        ...prev,
        [table]: {
          ...prev[table],
          loading: false,
          rows: allRows,
          scanned,
        }
      }));

      if (!allRows.length) {
        toast.ok('Sin resultados', `No hay ${table} para DNI ${cleanDni}`);
      } else {
        toast.ok('Listo', `${table}: ${allRows.length} registro/s`);
      }
    } catch (e: any) {
      setModules(prev => ({ ...prev, [table]: { ...prev[table], loading: false } }));
      toast.error('No se pudo cargar módulo', e?.message || 'Error');
    }
  }, [cleanDni, modules, toast]);

  const closeModule = useCallback((table: ModuleKey) => {
    trackAction('gestion_module_close', { module: table, dni: cleanDni });
    // Solo cierra el panel visual — mantiene rows para poder re-abrir rápido
    setModules(prev => ({ ...prev, [table]: { ...prev[table], open: false } }));
  }, [cleanDni]);

  const setSelectedIndex = useCallback((table: ModuleKey, index: number) => {
    setModules(prev => ({ ...prev, [table]: { ...prev[table], selectedIndex: index } }));
  }, []);

  const setTablePage = useCallback((table: ModuleKey, page: number) => {
    setModules(prev => ({ ...prev, [table]: { ...prev[table], tablePage: page } }));
  }, []);

  const setTablePageSize = useCallback((table: ModuleKey, size: number) => {
    setModules(prev => ({ ...prev, [table]: { ...prev[table], tablePageSize: size, tablePage: 1 } }));
  }, []);

  return {
    modules,
    loadModule,
    closeModule,
    setSelectedIndex,
    setTablePage,
    setTablePageSize,
    getModule: (key: ModuleKey) => modules[key],
    isModuleOpen: (key: ModuleKey) => modules[key].open,
    getSelectedRow: (key: ModuleKey) => {
      const st = modules[key];
      if (!st.rows.length) return null;
      const idx = Math.min(Math.max(0, st.selectedIndex), st.rows.length - 1);
      return st.rows[idx];
    }
  };
}
