// src/pages/ReportesPage/index.tsx
// ─────────────────────────────────────────────────────────────────────────────
// FIXES:
//   1. Cumpleaños: mes ahora envía número sin padding (parseInt lo necesita)
//   2. Cumpleaños: se agregó export a Word y PDF además de Excel
//   3. Cumpleaños: se muestra edad calculada si viene del servidor
//   4. Consultas dinámicas: _starts → _startsWith (corrección del operador)
//   5. Consultas dinámicas: export a Word, PDF, CSV además de Excel
//   6. Eliminado fallback roto (/personal?fecha_nacimiento_month= no existe)
// ─────────────────────────────────────────────────────────────────────────────
import React, { useState, useCallback } from 'react';
import { Layout } from '../../components/Layout';
import { apiFetch } from '../../api/http';
import { useToast } from '../../ui/toast';
import { exportToExcel, exportToPdf, exportToWord, exportToCSV, printTable } from '../../utils/export';

type TabKey = 'cumpleanos' | 'consultas';

// ─── Tab Cumpleaños ───────────────────────────────────────────────────────────
function CumpleanosTab() {
  const toast = useToast();
  const [mode, setMode] = useState<'dia' | 'mes' | 'rango'>('mes');
  const [fecha, setFecha] = useState('');
  const [mes, setMes] = useState('');
  const [desde, setDesde] = useState('');
  const [hasta, setHasta] = useState('');
  const [rows, setRows] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);

  const MESES = ['Enero','Febrero','Marzo','Abril','Mayo','Junio',
    'Julio','Agosto','Septiembre','Octubre','Noviembre','Diciembre'];

  const buscar = useCallback(async () => {
    let params = '';

    if (mode === 'dia') {
      if (!fecha) { toast.error('Seleccioná una fecha'); return; }
      const [, m, d] = fecha.split('-');
      // FIX: parseInt para quitar ceros a la izquierda que el backend necesita
      params = `mes=${parseInt(m, 10)}&dia=${parseInt(d, 10)}`;
    } else if (mode === 'mes') {
      if (!mes) { toast.error('Seleccioná un mes'); return; }
      // FIX: enviar número simple, no string con padding "01"
      params = `mes=${parseInt(mes, 10)}`;
    } else {
      if (!desde || !hasta) { toast.error('Completá las dos fechas del rango'); return; }
      if (desde > hasta) { toast.error('La fecha "desde" debe ser anterior a "hasta"'); return; }
      params = `desde=${desde}&hasta=${hasta}`;
    }

    setLoading(true);
    setRows([]);
    try {
      // GET /personal/cumpleanos?mes=1 (o &dia=15, o &desde=...&hasta=...)
      const res = await apiFetch<any>(`/personal/cumpleanos?${params}`);
      const data: any[] = res?.data || [];
      setRows(data);
      if (!data.length) {
        toast.error('Sin resultados', 'No hay agentes que cumplan años en esa fecha');
      } else {
        toast.ok(`${data.length} agente(s) encontrado(s)`);
      }
    } catch (e: any) {
      toast.error('Error al buscar', e?.message || 'Error');
    } finally {
      setLoading(false);
    }
  }, [mode, fecha, mes, desde, hasta, toast]);

  const titulo = () => {
    if (mode === 'dia' && fecha) return `Cumpleaños ${fecha.split('-').reverse().join('/')}`;
    if (mode === 'mes' && mes) return `Cumpleaños ${MESES[parseInt(mes, 10) - 1]}`;
    if (mode === 'rango') return `Cumpleaños ${desde} al ${hasta}`;
    return 'Cumpleaños';
  };

  const COLS = ['dni','apellido','nombre','fecha_nacimiento','edad','email','telefono'];
  const exportCols = rows.length
    ? COLS.filter(c => rows[0].hasOwnProperty(c))
    : COLS;

  const exportRows = rows.map(r => {
    const obj: any = {};
    exportCols.forEach(c => { obj[c] = r[c] ?? ''; });
    return obj;
  });

  return (
    <div style={{ display: 'grid', gap: 12 }}>
      {/* Controles */}
      <div className="card">
        <div style={{ display: 'flex', gap: 12, flexWrap: 'wrap', alignItems: 'flex-end' }}>

          {/* Modo */}
          <div>
            <div className="muted" style={{ fontSize: '0.75rem', marginBottom: 4 }}>Modo de búsqueda</div>
            <select className="input" value={mode}
              onChange={e => { setMode(e.target.value as any); setRows([]); }}
              style={{ minWidth: 150 }}>
              <option value="mes">Por mes</option>
              <option value="dia">Día exacto</option>
              <option value="rango">Rango de fechas</option>
            </select>
          </div>

          {mode === 'dia' && (
            <div>
              <div className="muted" style={{ fontSize: '0.75rem', marginBottom: 4 }}>Día y mes</div>
              <input className="input" type="date" value={fecha}
                onChange={e => setFecha(e.target.value)} />
            </div>
          )}

          {mode === 'mes' && (
            <div>
              <div className="muted" style={{ fontSize: '0.75rem', marginBottom: 4 }}>Mes</div>
              <select className="input" value={mes}
                onChange={e => setMes(e.target.value)} style={{ minWidth: 160 }}>
                <option value="">— Seleccionar —</option>
                {MESES.map((m, i) => (
                  // FIX: value es número sin padding (antes era "01", "02"...)
                  <option key={i + 1} value={String(i + 1)}>{m}</option>
                ))}
              </select>
            </div>
          )}

          {mode === 'rango' && (
            <>
              <div>
                <div className="muted" style={{ fontSize: '0.75rem', marginBottom: 4 }}>Desde</div>
                <input className="input" type="date" value={desde}
                  onChange={e => setDesde(e.target.value)} />
              </div>
              <div>
                <div className="muted" style={{ fontSize: '0.75rem', marginBottom: 4 }}>Hasta</div>
                <input className="input" type="date" value={hasta}
                  onChange={e => setHasta(e.target.value)} />
              </div>
            </>
          )}

          <button className="btn"
            style={{ background: '#2563eb', color: '#fff', height: 36, minWidth: 100 }}
            disabled={loading} onClick={buscar}>
            {loading ? '⏳ Buscando…' : '🔍 Buscar'}
          </button>
        </div>
      </div>

      {/* Resultados */}
      {rows.length > 0 && (
        <div className="card">
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center',
            flexWrap: 'wrap', gap: 8, marginBottom: 12 }}>
            <strong style={{ fontSize: '0.9rem' }}>
              🎂 {rows.length} agente(s) — {titulo()}
            </strong>
            <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
              <button className="btn" onClick={() => printTable(titulo(), exportRows)}>🖨 Imprimir</button>
              <button className="btn" onClick={() => exportToExcel(`cumpleanos_${mode}`, exportRows)}>📊 Excel</button>
              <button className="btn" onClick={() => exportToPdf(`cumpleanos_${mode}`, exportRows, titulo())}>📄 PDF</button>
              <button className="btn" onClick={() => exportToWord(`cumpleanos_${mode}`, exportRows, titulo())}>📝 Word</button>
              <button className="btn" onClick={() => exportToCSV(`cumpleanos_${mode}`, exportRows)}>CSV</button>
            </div>
          </div>

          <div style={{ overflowX: 'auto' }}>
            <table className="table" style={{ width: '100%', fontSize: '0.84rem' }}>
              <thead>
                <tr>
                  {exportCols.map(c => (
                    <th key={c} style={{ padding: '6px 10px', textAlign: 'left', whiteSpace: 'nowrap' }}>
                      {c.toUpperCase().replace(/_/g, ' ')}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {rows.map((r, i) => (
                  <tr key={i}>
                    {exportCols.map(c => (
                      <td key={c} style={{ padding: '5px 10px' }}>
                        {c === 'fecha_nacimiento' && r[c]
                          ? new Date(r[c]).toLocaleDateString('es-AR')
                          : (r[c] != null ? String(r[c]) : '—')}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}

// ─── Tab Consultas dinámicas ───────────────────────────────────────────────────
const QUERY_TABLES = [
  { key: 'personal',         label: 'Personal',
    cols: ['dni','apellido','nombre','fecha_nacimiento','cuil','email','telefono','domicilio','estado_empleo','observaciones','created_at'] },
  { key: 'agentes',          label: 'Agentes (datos laborales)',
    cols: ['id','dni','estado_empleo','fecha_ingreso','fecha_egreso','ley_id','planta_id','categoria_id','funcion_id','ocupacion_id','regimen_horario_id','sector_id','dependencia_id'] },
  { key: 'agentes_servicios',label: 'Agentes - Servicios',
    cols: ['id','dni','servicio_id','fecha_desde','fecha_hasta','observaciones'] },
  { key: 'agentexdni1',      label: 'Vista completa agente',
    cols: ['id','dni','apellido','nombre','fecha_nacimiento','cuil','agente_id','ley_id','ley_nombre','dependencia_id','reparticion_nombre','servicio_nombre','jefe_nombre','fecha_desde','fecha_hasta','estado_empleo','fecha_ingreso'] },
  { key: 'consultas',        label: 'Consultas',
    cols: ['id','dni','motivo_consulta','explicacion','atendido_por','hora_atencion','created_at'] },
  { key: 'pedidos',          label: 'Pedidos',
    cols: ['id','dni','pedido','estado','lugar','fecha','observacion','created_at'] },
  { key: 'tblarchivos',      label: 'Documentos (tblarchivos)',
    cols: ['id','dni','tipo','numero','fecha','nombre','nombre_archivo_original','tamanio','anio','created_at'] },
];

type FilterOp = 'contains' | 'eq' | 'startsWith' | 'notempty' | 'gt' | 'lt';
interface Filter { col: string; op: FilterOp; val: string; }

function ConsultasTab() {
  const toast = useToast();
  const [tableKey, setTableKey] = useState('personal');
  const [selectedCols, setSelectedCols] = useState<string[]>([]);
  const [filters, setFilters] = useState<Filter[]>([]);
  const [rows, setRows] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [limit, setLimit] = useState(200);
  const [page, setPage] = useState(1);
  const [pageSize] = useState(50);

  const tableDef = QUERY_TABLES.find(t => t.key === tableKey) || QUERY_TABLES[0];
  const allCols  = tableDef.cols;
  const visCols  = selectedCols.length ? selectedCols : allCols;

  const toggleCol = (col: string) =>
    setSelectedCols(prev => prev.includes(col) ? prev.filter(c => c !== col) : [...prev, col]);

  const addFilter    = () => setFilters(prev => [...prev, { col: allCols[0], op: 'contains', val: '' }]);
  const removeFilter = (i: number) => setFilters(prev => prev.filter((_, idx) => idx !== i));
  const updateFilter = (i: number, field: keyof Filter, val: string) =>
    setFilters(prev => { const next = [...prev]; next[i] = { ...next[i], [field]: val }; return next; });

  const buscar = useCallback(async () => {
    setLoading(true); setRows([]); setPage(1);
    try {
      const params: string[] = [`limit=${limit}`, 'page=1'];
      for (const f of filters) {
        if (!f.col) continue;
        if (f.op !== 'notempty' && !f.val.trim()) continue;
        // FIX: operadores corregidos según lo que soporta el CRUD del backend
        if (f.op === 'contains')    params.push(`${f.col}_contains=${encodeURIComponent(f.val)}`);
        else if (f.op === 'eq')     params.push(`${f.col}=${encodeURIComponent(f.val)}`);
        else if (f.op === 'startsWith') params.push(`${f.col}_startsWith=${encodeURIComponent(f.val)}`);
        else if (f.op === 'gt')     params.push(`${f.col}_gt=${encodeURIComponent(f.val)}`);
        else if (f.op === 'lt')     params.push(`${f.col}_lt=${encodeURIComponent(f.val)}`);
        // notempty no tiene soporte backend estándar, lo hacemos en frontend
      }

      const res = await apiFetch<any>(`/${tableKey}?${params.join('&')}`);
      let data: any[] = res?.data || [];

      // Filtro notempty client-side
      const notemptyFilters = filters.filter(f => f.op === 'notempty' && f.col);
      if (notemptyFilters.length) {
        data = data.filter(r => notemptyFilters.every(f => r[f.col] != null && r[f.col] !== ''));
      }

      setRows(data);
      if (!data.length) toast.error('Sin resultados');
      else toast.ok(`${data.length} registro(s)`);
    } catch (e: any) {
      toast.error('Error', e?.message || 'Error al consultar');
    } finally {
      setLoading(false);
    }
  }, [tableKey, filters, limit, toast]);

  const exportRows = rows.map(r => {
    const obj: any = {};
    visCols.forEach(c => { obj[c] = r[c] ?? ''; });
    return obj;
  });

  const titulo = `${tableDef.label} — consulta`;
  const total = Math.max(1, Math.ceil(rows.length / pageSize));
  const curPage = Math.min(page, total);
  const start = (curPage - 1) * pageSize;
  const pageRows = rows.slice(start, start + pageSize);

  return (
    <div style={{ display: 'grid', gap: 12 }}>
      {/* Tabla + límite */}
      <div className="card">
        <div style={{ display: 'flex', gap: 12, flexWrap: 'wrap', alignItems: 'flex-end' }}>
          <div style={{ flex: '1 1 250px' }}>
            <div className="muted" style={{ fontSize: '0.75rem', marginBottom: 4 }}>Tabla / Vista</div>
            <select className="input" value={tableKey}
              onChange={e => { setTableKey(e.target.value); setSelectedCols([]); setFilters([]); setRows([]); }}>
              {QUERY_TABLES.map(t => <option key={t.key} value={t.key}>{t.label}</option>)}
            </select>
          </div>
          <div>
            <div className="muted" style={{ fontSize: '0.75rem', marginBottom: 4 }}>Máx. filas</div>
            <select className="input" value={limit} onChange={e => setLimit(Number(e.target.value))}>
              {[50,100,200,500,1000].map(n => <option key={n} value={n}>{n}</option>)}
            </select>
          </div>
        </div>

        {/* Columnas visibles */}
        <div style={{ marginTop: 12 }}>
          <div className="muted" style={{ fontSize: '0.75rem', marginBottom: 6 }}>
            Columnas &nbsp;
            <button className="btn" style={{ fontSize: '0.7rem', padding: '1px 8px' }}
              onClick={() => setSelectedCols([])}>Reset</button>
          </div>
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: 5 }}>
            {allCols.map(col => (
              <label key={col} style={{
                cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 4,
                background: visCols.includes(col) ? 'rgba(37,99,235,0.25)' : 'rgba(255,255,255,0.06)',
                border: '1px solid rgba(255,255,255,0.12)', borderRadius: 5,
                padding: '2px 8px', fontSize: '0.74rem',
              }}>
                <input type="checkbox" checked={visCols.includes(col)} onChange={() => toggleCol(col)}
                  style={{ width: 12, height: 12 }} />
                {col}
              </label>
            ))}
          </div>
        </div>
      </div>

      {/* Filtros */}
      <div className="card">
        <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 8 }}>
          <strong style={{ fontSize: '0.88rem' }}>🔍 Filtros</strong>
          <button className="btn" onClick={addFilter} style={{ fontSize: '0.78rem' }}>+ Agregar filtro</button>
        </div>
        {filters.map((f, i) => (
          <div key={i} style={{ display: 'flex', gap: 8, marginBottom: 6, flexWrap: 'wrap', alignItems: 'center' }}>
            <select className="input" value={f.col} onChange={e => updateFilter(i, 'col', e.target.value)}
              style={{ minWidth: 140, fontSize: '0.82rem' }}>
              {allCols.map(c => <option key={c} value={c}>{c}</option>)}
            </select>
            <select className="input" value={f.op} onChange={e => updateFilter(i, 'op', e.target.value as FilterOp)}
              style={{ minWidth: 150, fontSize: '0.82rem' }}>
              <option value="contains">contiene</option>
              <option value="eq">igual a</option>
              <option value="startsWith">empieza con</option>
              <option value="gt">mayor que</option>
              <option value="lt">menor que</option>
              <option value="notempty">no vacío (local)</option>
            </select>
            {f.op !== 'notempty' && (
              <input className="input" value={f.val} onChange={e => updateFilter(i, 'val', e.target.value)}
                placeholder="valor…" style={{ minWidth: 140, fontSize: '0.82rem' }} />
            )}
            <button className="btn" onClick={() => removeFilter(i)}
              style={{ color: '#f87171', fontSize: '0.8rem', padding: '2px 8px' }}>✕</button>
          </div>
        ))}
        {!filters.length && (
          <div className="muted" style={{ fontSize: '0.8rem' }}>Sin filtros — muestra hasta {limit} registros</div>
        )}
      </div>

      {/* Acciones */}
      <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
        <button className="btn" style={{ background: '#2563eb', color: '#fff' }}
          disabled={loading} onClick={buscar}>
          {loading ? '⏳ Consultando…' : '▶ Ejecutar consulta'}
        </button>
        {rows.length > 0 && (
          <>
            <button className="btn" onClick={() => printTable(titulo, exportRows)}>🖨 Imprimir</button>
            <button className="btn" onClick={() => exportToExcel(`consulta_${tableKey}`, exportRows)}>📊 Excel</button>
            <button className="btn" onClick={() => exportToPdf(`consulta_${tableKey}`, exportRows, titulo)}>📄 PDF</button>
            <button className="btn" onClick={() => exportToWord(`consulta_${tableKey}`, exportRows, titulo)}>📝 Word</button>
            <button className="btn" onClick={() => exportToCSV(`consulta_${tableKey}`, exportRows)}>CSV</button>
            <span className="muted" style={{ fontSize: '0.8rem', alignSelf: 'center' }}>
              {rows.length} registro(s)
            </span>
          </>
        )}
      </div>

      {/* Tabla de resultados + paginación */}
      {rows.length > 0 && (
        <div className="card">
          <div style={{ overflowX: 'auto' }}>
            <table style={{ width: '100%', fontSize: '0.8rem', borderCollapse: 'collapse' }}>
              <thead>
                <tr style={{ background: 'rgba(37,99,235,0.2)' }}>
                  {visCols.map(c => (
                    <th key={c} style={{ padding: '6px 10px', textAlign: 'left',
                      whiteSpace: 'nowrap', borderBottom: '1px solid rgba(255,255,255,0.1)',
                      fontSize: '0.72rem', color: '#94a3b8' }}>
                      {c.toUpperCase().replace(/_/g, ' ')}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {pageRows.map((r, i) => (
                  <tr key={i} style={{ borderTop: '1px solid rgba(255,255,255,0.05)' }}>
                    {visCols.map(c => (
                      <td key={c} style={{ padding: '4px 10px', maxWidth: 280,
                        overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}
                        title={String(r[c] ?? '')}>
                        {r[c] == null ? <span className="muted">—</span> : String(r[c])}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {total > 1 && (
            <div style={{ display: 'flex', justifyContent: 'center', gap: 8, marginTop: 12, alignItems: 'center' }}>
              <button className="btn" onClick={() => setPage(p => Math.max(1, p - 1))}
                disabled={curPage <= 1}>◀</button>
              <span className="badge">Pág. {curPage} / {total}</span>
              <button className="btn" onClick={() => setPage(p => Math.min(total, p + 1))}
                disabled={curPage >= total}>▶</button>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

// ─── Page ─────────────────────────────────────────────────────────────────────
export function ReportesPage() {
  const [tab, setTab] = useState<TabKey>('cumpleanos');

  return (
    <Layout title="Reportes y Consultas" showBack>
      <div style={{ marginBottom: 12, display: 'flex', gap: 8 }}>
        <button className={`btn${tab === 'cumpleanos' ? ' active' : ''}`}
          onClick={() => setTab('cumpleanos')}>
          🎂 Cumpleaños
        </button>
        <button className={`btn${tab === 'consultas' ? ' active' : ''}`}
          onClick={() => setTab('consultas')}>
          📊 Consultas dinámicas
        </button>
      </div>

      {tab === 'cumpleanos' && <CumpleanosTab />}
      {tab === 'consultas' && <ConsultasTab />}
    </Layout>
  );
}
