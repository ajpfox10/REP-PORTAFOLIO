// utils/export.ts
// ─────────────────────────────────────────────────────────────────────────────
// FIXES:
//   1. Extensión doble: exportToExcel('cumpleanos.xlsx', rows) guardaba
//      'cumpleanos.xlsx.xlsx'. Ahora se limpia la extensión del filename
//      antes de agregar la correcta.
//   2. Se agrega exportToCSV() — alternativa simple que no necesita librería
//   3. printTable() mejorado: título + fecha + tabla con estilos hospitalsitos
//   4. exportToPdf() con orientación landscape cuando hay muchas columnas
// ─────────────────────────────────────────────────────────────────────────────
import { saveAs } from 'file-saver';
import * as XLSX from 'xlsx';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import { Document, Packer, Paragraph, Table, TableCell, TableRow, TextRun,
  HeadingLevel, AlignmentType, BorderStyle, WidthType } from 'docx';

type Row = Record<string, any>;

function toText(v: any): string {
  if (v === null || v === undefined) return '';
  if (typeof v === 'object') return JSON.stringify(v);
  return String(v);
}

/** Limpia extensión doble: "archivo.xlsx" → "archivo", "archivo" → "archivo" */
function cleanName(filename: string, ext: string): string {
  const dotExt = ext.startsWith('.') ? ext : `.${ext}`;
  return filename.endsWith(dotExt)
    ? filename.slice(0, -dotExt.length)
    : filename;
}

// ── EXCEL ─────────────────────────────────────────────────────────────────────
export function exportToExcel(filename: string, rows: Row[]) {
  if (!rows.length) return;
  const name = cleanName(filename, 'xlsx');
  const ws = XLSX.utils.json_to_sheet(rows);

  // Auto-ancho de columnas
  const cols = Object.keys(rows[0]);
  const colWidths = cols.map(k => ({
    wch: Math.max(k.length, ...rows.slice(0, 100).map(r => toText(r[k]).length), 10),
  }));
  ws['!cols'] = colWidths;

  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, 'Datos');
  const out = XLSX.write(wb, { type: 'array', bookType: 'xlsx' });
  saveAs(
    new Blob([out], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' }),
    `${name}.xlsx`
  );
}

// ── CSV ───────────────────────────────────────────────────────────────────────
export function exportToCSV(filename: string, rows: Row[]) {
  if (!rows.length) return;
  const name = cleanName(filename, 'csv');
  const cols = Object.keys(rows[0]);
  const escape = (v: any) => {
    const s = toText(v);
    return s.includes(',') || s.includes('"') || s.includes('\n')
      ? `"${s.replace(/"/g, '""')}"` : s;
  };
  const lines = [
    cols.join(','),
    ...rows.map(r => cols.map(c => escape(r[c])).join(',')),
  ];
  const blob = new Blob(['\ufeff' + lines.join('\r\n')], { type: 'text/csv;charset=utf-8;' });
  saveAs(blob, `${name}.csv`);
}

// ── PDF ───────────────────────────────────────────────────────────────────────
export function exportToPdf(filename: string, rows: Row[], title?: string) {
  if (!rows.length) return;
  const name = cleanName(filename, 'pdf');
  const cols = Object.keys(rows[0]);
  const landscape = cols.length > 6;
  const doc = new jsPDF({ orientation: landscape ? 'landscape' : 'portrait' });

  if (title) {
    doc.setFontSize(13);
    doc.text(title, 14, 14);
    doc.setFontSize(10);
    doc.text(`Generado: ${new Date().toLocaleString('es-AR')}`, 14, 20);
  }

  const body = rows.map(r => cols.map(c => toText(r[c])));
  autoTable(doc, {
    head: [cols.map(c => c.toUpperCase())],
    body,
    startY: title ? 26 : 14,
    styles: { fontSize: 7, cellPadding: 2 },
    headStyles: { fillColor: [37, 99, 235], textColor: 255, fontStyle: 'bold' },
    alternateRowStyles: { fillColor: [245, 247, 250] },
  });

  doc.save(`${name}.pdf`);
}

// ── WORD ──────────────────────────────────────────────────────────────────────
export async function exportToWord(filename: string, rows: Row[], title?: string) {
  if (!rows.length) return;
  const name = cleanName(filename, 'docx');
  const cols = Object.keys(rows[0]);

  const borderConfig = {
    top:    { style: BorderStyle.SINGLE, size: 1, color: 'CCCCCC' },
    bottom: { style: BorderStyle.SINGLE, size: 1, color: 'CCCCCC' },
    left:   { style: BorderStyle.SINGLE, size: 1, color: 'CCCCCC' },
    right:  { style: BorderStyle.SINGLE, size: 1, color: 'CCCCCC' },
  };

  const headerRow = new TableRow({
    children: cols.map(c => new TableCell({
      borders: borderConfig,
      shading: { fill: '2563EB' },
      children: [new Paragraph({
        children: [new TextRun({ text: c.toUpperCase(), bold: true, color: 'FFFFFF', size: 18 })]
      })]
    }))
  });

  const dataRows = rows.map((r, ri) => new TableRow({
    children: cols.map(c => new TableCell({
      borders: borderConfig,
      shading: { fill: ri % 2 === 0 ? 'FFFFFF' : 'F5F7FA' },
      children: [new Paragraph({
        children: [new TextRun({ text: toText(r[c]), size: 16 })]
      })]
    }))
  }));

  const sections = [];
  if (title) {
    sections.push(new Paragraph({
      text: title,
      heading: HeadingLevel.HEADING_1,
    }));
    sections.push(new Paragraph({
      children: [new TextRun({
        text: `Generado: ${new Date().toLocaleString('es-AR')} · ${rows.length} registro(s)`,
        size: 18, color: '64748B',
      })]
    }));
    sections.push(new Paragraph({ text: '' }));
  }

  sections.push(new Table({
    width: { size: 100, type: WidthType.PERCENTAGE },
    rows: [headerRow, ...dataRows],
  }));

  const doc = new Document({ sections: [{ children: sections }] });
  const blob = await Packer.toBlob(doc);
  saveAs(blob, `${name}.docx`);
}

// ── PRINT ─────────────────────────────────────────────────────────────────────
export function printTable(title: string, rows: Row[]) {
  if (!rows.length) return;
  const cols = Object.keys(rows[0]);
  const fecha = new Date().toLocaleString('es-AR');

  const html = `<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>${title}</title>
  <style>
    * { box-sizing: border-box; }
    body { font-family: 'Segoe UI', Arial, sans-serif; padding: 20px; color: #222; }
    h2  { font-size: 16px; margin: 0 0 4px; }
    .meta { font-size: 11px; color: #666; margin-bottom: 14px; }
    table { border-collapse: collapse; width: 100%; font-size: 11px; }
    th { background: #2563eb; color: #fff; padding: 6px 8px; text-align: left;
         font-size: 10px; font-weight: 600; letter-spacing: 0.03em; }
    td { padding: 5px 8px; border-bottom: 1px solid #e2e8f0; }
    tr:nth-child(even) td { background: #f8fafc; }
    @media print {
      @page { margin: 1.5cm; size: landscape; }
      body { padding: 0; }
    }
  </style>
</head>
<body>
  <h2>${title}</h2>
  <div class="meta">Impreso: ${fecha} · ${rows.length} registro(s)</div>
  <table>
    <thead><tr>${cols.map(c => `<th>${c.toUpperCase()}</th>`).join('')}</tr></thead>
    <tbody>
      ${rows.map(r =>
        `<tr>${cols.map(c => `<td>${toText(r[c])}</td>`).join('')}</tr>`
      ).join('')}
    </tbody>
  </table>
</body>
</html>`;

  const w = window.open('', '_blank');
  if (!w) { alert('Habilitá popups para imprimir'); return; }
  w.document.open();
  w.document.write(html);
  w.document.close();
  w.focus();
  setTimeout(() => w.print(), 400);
}
