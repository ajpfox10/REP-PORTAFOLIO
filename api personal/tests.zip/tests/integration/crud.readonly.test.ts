// tests/integration/crud.readonly.test.ts
import path from "path";
import request from "supertest";

// Cargar .env ANTES de requerir módulos que leen env (Sequelize/env config)
require("dotenv").config({ path: path.resolve(process.cwd(), ".env") });

const RUN = process.env.TEST_INTEGRATION === "1";

(RUN ? describe : describe.skip)("integration (DB) - CRUD read-only", () => {
  jest.setTimeout(60_000);

  it("GET /api/v1/tables, GET list y GET by id (si hay PK simple y hay filas)", async () => {
    // Cache de schema separado para integración
    process.env.SCHEMA_CACHE_PATH = path.resolve(
      process.cwd(),
      ".cache",
      "schema.integration.test.json"
    );

    // Importar DESPUÉS de cargar dotenv
    const { createSequelize } = require("../../src/db/sequelize");
    const { schemaBootstrap } = require("../../src/bootstrap/schemaBootstrap");
    const { buildModels } = require("../../src/models/buildModels");
    const { createApp } = require("../../src/app");
    const { mountRoutes } = require("../../src/routes");

    const sequelize = createSequelize();
    await sequelize.authenticate();

    try {
      const schema = await schemaBootstrap(sequelize);
      const models = buildModels(sequelize, schema);

      const app = createApp();
      mountRoutes(app, sequelize, schema, models);

      // 1) tables
      const tablesRes = await request(app).get("/api/v1/tables").expect(200);
      expect(tablesRes.body).toHaveProperty("ok", true);
      expect(Array.isArray(tablesRes.body.data)).toBe(true);

      const tables: string[] = tablesRes.body.data;
      expect(tables.length).toBeGreaterThan(0);

      // 2) buscar una tabla con PK simple y al menos 1 fila
      let chosen: { table: string; pkCol: string; pkVal: any } | null = null;

      for (const t of tables.slice(0, 80)) {
        const meta = schema?.tables?.[t];
        const pk: string[] = meta?.primaryKey || [];

        if (pk.length !== 1) continue;

        const listRes = await request(app)
          .get(`/api/v1/${encodeURIComponent(t)}?page=1&limit=1`)
          .expect(200);

        const rows = listRes.body?.data?.rows;
        if (!Array.isArray(rows) || rows.length === 0) continue;

        const pkCol = pk[0];
        const pkVal = rows[0]?.[pkCol];

        if (pkVal === undefined || pkVal === null) continue;

        chosen = { table: t, pkCol, pkVal };
        break;
      }

      // Si tu DB no tiene filas en tablas con PK simple, no fallamos, solo validamos tablas+list
      if (!chosen) return;

      // 3) get by id
      await request(app)
        .get(
          `/api/v1/${encodeURIComponent(chosen.table)}/${encodeURIComponent(
            String(chosen.pkVal)
          )}`
        )
        .expect(200);
    } finally {
      await sequelize.close();
    }
  });

  it("GET /api/v1/__nope__ devuelve 404 con JSON ok=false", async () => {
    process.env.SCHEMA_CACHE_PATH = path.resolve(
      process.cwd(),
      ".cache",
      "schema.integration.test.json"
    );

    const { createSequelize } = require("../../src/db/sequelize");
    const { schemaBootstrap } = require("../../src/bootstrap/schemaBootstrap");
    const { buildModels } = require("../../src/models/buildModels");
    const { createApp } = require("../../src/app");
    const { mountRoutes } = require("../../src/routes");

    const sequelize = createSequelize();
    await sequelize.authenticate();

    try {
      const schema = await schemaBootstrap(sequelize);
      const models = buildModels(sequelize, schema);

      const app = createApp();
      mountRoutes(app, sequelize, schema, models);

      const res = await request(app).get("/api/v1/__nope__").expect(404);
      expect(res.body).toHaveProperty("ok", false);
    } finally {
      await sequelize.close();
    }
  });
});
