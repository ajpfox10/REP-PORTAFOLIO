process.env.NODE_ENV = 'test';
process.env.PORT = process.env.PORT || '3001';

// Required by env.ts (fail-fast)
process.env.DB_HOST = process.env.DB_HOST || '127.0.0.1';
process.env.DB_PORT = process.env.DB_PORT || '3306';
process.env.DB_NAME = process.env.DB_NAME || 'personalv5_test';
process.env.DB_USER = process.env.DB_USER || 'root';
process.env.DB_PASSWORD = process.env.DB_PASSWORD || '';

// Disable OpenAPI validation by default for unit tests
process.env.ENABLE_OPENAPI_VALIDATION = 'false';
