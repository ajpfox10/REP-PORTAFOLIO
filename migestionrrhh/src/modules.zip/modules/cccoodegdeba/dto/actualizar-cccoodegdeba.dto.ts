import { PartialType } from '@nestjs/swagger';
import { CrearCccoodegdebaDto } from './cccoodegdeba.dto';

export class ActualizarCccoodegdebaDto extends PartialType(CrearCccoodegdebaDto) { }
