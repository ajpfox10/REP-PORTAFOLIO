// src/modules/ministerios/ministerios.service.ts

import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/sequelize';
import { Ministerios } from './ministerios.model';

@Injectable()
export class MinisteriosService {
    constructor(
        @InjectModel(Ministerios)
        private readonly model: typeof Ministerios,
    ) { }

    async crear(data: Partial<Ministerios>): Promise<Ministerios> {
        return this.model.create({
            ...data,
            fechaDeAlta: new Date(),
        });
    }

    async obtenerTodos(): Promise<Ministerios[]> {
        return this.model.findAll();
    }

    async obtenerPorId(id: number): Promise<Ministerios | null> {
        return this.model.findByPk(id);
    }
}
