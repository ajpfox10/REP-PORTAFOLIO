import { Controller } from '@nestjs/common';

@Controller('personal')
export class PersonalController {
    // Controlador generado para la tabla 'personal'
}
