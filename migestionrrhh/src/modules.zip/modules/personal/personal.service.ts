import { Injectable } from '@nestjs/common';

@Injectable()
export class PersonalService {
    // Servicio para manejar la lógica de negocio de la tabla 'personal'
}
