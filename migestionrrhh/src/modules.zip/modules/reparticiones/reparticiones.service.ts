import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectModel } from '@nestjs/sequelize';
import { Reparticiones } from '../tareas/reparticiones/reparticiones.model';
import { CrearReparticionesDto } from './dto/crear-reparticiones.dto';

@Injectable()
export class ReparticionesService {
    constructor(
        @InjectModel(Reparticiones)
        private readonly model: typeof Reparticiones,
    ) { }

    async crear(data: CrearReparticionesDto): Promise<Reparticiones> {
        return this.model.create({
            ...data,
            fechaDeAlta: new Date(),
        } as Reparticiones);
    }

    async buscarTodos(): Promise<Reparticiones[]> {
        return this.model.findAll();
    }

    async buscarPorId(id: number): Promise<Reparticiones> {
        const rep = await this.model.findByPk(id);
        if (!rep) {
            throw new NotFoundException('Repartici�n no encontrada');
        }
        return rep;
    }

    async actualizar(id: number, data: Partial<CrearReparticionesDto>): Promise<Reparticiones> {
        const rep = await this.buscarPorId(id);
        await rep.update(data);
        return rep;
    }

    async eliminar(id: number): Promise<void> {
        const rep = await this.buscarPorId(id);
        await rep.destroy();
    }
}
