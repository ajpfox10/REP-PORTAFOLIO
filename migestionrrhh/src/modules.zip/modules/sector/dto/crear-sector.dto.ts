export class CrearSectorDto {
    readonly nombre!: string;
    readonly usuarioCarga!: string;
}
