export class CrearTareasDto {
  comentariosagenterealizo?: string;
  tarea?: string;
  fechadebajadetarea?: Date;
  fechadealtadetarea?: Date;
  asifgnadoa?: string;
    usuarioCarga!: string;
}