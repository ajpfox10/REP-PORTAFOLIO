import { Body, Controller, Delete, Get, Param, Post } from '@nestjs/common';
import { TareasService } from './tareas.service';
import { CrearTareasDto } from './dto/crear-tareas.dto';

@Controller('tareas')
export class TareasController {
  constructor(private readonly tareasService: TareasService) {}

  @Post()
  crear(@Body() dto: CrearTareasDto) {
    return this.tareasService.crear(dto);
  }

  @Get()
  obtenerTodas() {
    return this.tareasService.obtenerTodas();
  }

  @Get(':id')
  obtenerPorId(@Param('id') id: number) {
    return this.tareasService.obtenerPorId(id);
  }

  @Delete(':id')
  eliminar(@Param('id') id: number) {
    return this.tareasService.eliminar(id);
  }
}