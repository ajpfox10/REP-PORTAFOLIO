import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/sequelize';
import { Tareas } from './tareas.model';
import { CrearTareasDto } from './dto/crear-tareas.dto';

@Injectable()
export class TareasService {
  constructor(@InjectModel(Tareas) private tareasModel: typeof Tareas) {}

  async crear(dto: CrearTareasDto): Promise<Tareas> {
    return this.tareasModel.create({ ...dto, fechaDeAlta: new Date() });
  }

  async obtenerTodas(): Promise<Tareas[]> {
    return this.tareasModel.findAll();
  }

  async obtenerPorId(id: number): Promise<Tareas> {
    return this.tareasModel.findByPk(id);
  }

  async eliminar(id: number): Promise<void> {
    await this.tareasModel.destroy({ where: { ID: id } });
  }
}