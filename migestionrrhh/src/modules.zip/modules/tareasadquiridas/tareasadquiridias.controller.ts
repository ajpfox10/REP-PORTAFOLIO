import {
    Controller,
    Get,
    Post,
    Body,
    Param,
    Delete,
    Put,
    UseGuards,
} from '@nestjs/common';
import { TareasadquiridiasService } from './tareasadquiridias.service';
import { CrearTareasadquiridiasDto } from './dto/crear-tareasadquiridias.dto';
import { JwtAuthGuard } from '@auth/guards/jwt-auth.guard';
import { RolesGuard } from '@auth/guards/roles.guard';
import { Roles } from '@auth/decoradores/roles.decorator';
import { Rol } from '@auth/interfaces/rol.enum';
import { ApiTags } from '@nestjs/swagger';


@ApiTags('Tareas Adquiridias')
@UseGuards(JwtAuthGuard, RolesGuard)
@Controller('tareasadquiridias')
export class TareasadquiridiasController {
    constructor(private readonly tareasadquiridiasService: TareasadquiridiasService) { }

    @Post()
    @Roles(Rol.ADMIN)
    crear(@Body() dto: CrearTareasadquiridiasDto) {
        return this.tareasadquiridiasService.crear(dto);
    }

    @Get()
    @Roles(Rol.ADMIN, Rol.USER)
    buscarTodos() {
        return this.tareasadquiridiasService.buscarTodos();
    }

    @Get(':id')
    @Roles(Rol.ADMIN, Rol.USER)
    buscarPorId(@Param('id') id: number) {
        return this.tareasadquiridiasService.buscarPorId(id);
    }

    @Put(':id')
    @Roles(Rol.ADMIN)
    actualizar(@Param('id') id: number, @Body() dto: CrearTareasadquiridiasDto) {
        return this.tareasadquiridiasService.actualizar(id, dto);
    }

    @Delete(':id')
    @Roles(Rol.ADMIN)
    eliminar(@Param('id') id: number) {
        return this.tareasadquiridiasService.eliminar(id);
    }
}
