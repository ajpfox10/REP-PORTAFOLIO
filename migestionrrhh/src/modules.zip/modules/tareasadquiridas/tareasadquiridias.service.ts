import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/sequelize';
import { Tareasadquiridias } from './tareasadquiridias.model';

@Injectable()
export class TareasadquiridiasService {
    constructor(
        @InjectModel(Tareasadquiridias)
        private readonly modelo: typeof Tareasadquiridias,
    ) { }

    async crear(dto: Partial<Tareasadquiridias>, usuario: string): Promise<Tareasadquiridias> {
        return await this.modelo.create({
            ...dto,
            fechaDeAlta: new Date(),
            usuarioCarga: usuario,
        } as Tareasadquiridias);
    }

    async obtenerTodos(): Promise<Tareasadquiridias[]> {
        return await this.modelo.findAll();
    }

    async obtenerPorId(id: number): Promise<Tareasadquiridias | null> {
        return await this.modelo.findByPk(id);
    }

    async actualizar(id: number, cambios: Partial<Tareasadquiridias>): Promise<void> {
        await this.modelo.update(cambios, { where: { id } });
    }

    async eliminar(id: number): Promise<void> {
        await this.modelo.destroy({ where: { id } });
    }
}

