# VetPro API - Production release pack

## Cambios aplicados
- Build separado para app y tests (`tsconfig.build.json`, `tsconfig.test.json`).
- Dockerfile tolera ausencia de `package-lock.json`.
- Validación mínima de OpenAPI real en build/runtime.
- `.dockerignore` para reducir contexto y evitar basura.
- `@types/express` alineado con Express 4.

## Salida a producción
1. Completar variables de entorno desde `.env.example`.
2. Crear `package-lock.json` en un entorno con internet antes de publicar imagen final.
3. Ejecutar:
   - `npm install`
   - `npm run lint`
   - `npm test`
   - `npm run openapi:gen`
   - `docker build --target runtime -t vetpro-api:prod .`
4. Aplicar `sql/master.sql` y `sql/tenant.sql` o migraciones por tenant.
5. Desplegar tres procesos:
   - API
   - Worker
   - Scheduler (una sola instancia)

## Bloqueantes que todavía requieren validación real
- Correr build/tests con dependencias instaladas.
- Probar conexión MySQL y Redis reales.
- Validar flujos Stripe/SES/S3/WhatsApp con credenciales productivas.
- Hacer smoke test E2E de login, refresh, tenant resolution, turnos, files y billing.

## Recomendación
No publicar como “10/10” sin pasar CI real. Este pack deja la base mucho mejor preparada, pero todavía necesita una corrida final en entorno de integración.
