import fs from "node:fs";
import path from "node:path";

const candidates = [
  path.resolve("docs/openapi.generated.yaml"),
  path.resolve("docs/openapi.yaml"),
];

const existing = candidates.find((p) => fs.existsSync(p));
if (!existing) {
  console.error("[openapi] Missing spec. Generate it with: npm run openapi:gen");
  process.exit(1);
}

const raw = fs.readFileSync(existing, "utf8");
const requiredSnippets = ["openapi:", "paths:", "components:"];
const missing = requiredSnippets.filter((s) => !raw.includes(s));
if (missing.length) {
  console.error(`[openapi] Invalid spec at ${existing}. Missing sections: ${missing.join(", ")}`);
  process.exit(1);
}

console.log(`[openapi] Spec OK: ${existing}`);
